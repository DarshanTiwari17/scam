// Listen for messages from the popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "CHECK_WEBSITE") {
        const url = message.url;
        checkWebsiteWithVirusTotal(url).then(result => {
            sendResponse({ result });
        }).catch(error => {
            console.error("Error:", error.message);
            sendResponse({ error: error.message });
        });
        return true; // Keeps the async response open
    }
});

// ✅ Function to check URL using VirusTotal API
async function checkWebsiteWithVirusTotal(url) {
    const apiKey = await getVirusTotalApiKey();
    if (!apiKey) {
        throw new Error("Missing API key! Please set it in storage.");
    }

    const apiUrl = `https://www.virustotal.com/api/v3/urls`;

    try {
        // Encode the URL for VirusTotal scanning
        const response = await fetch(apiUrl, {
            method: "POST",
            headers: {
                "x-apikey": apiKey,
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: new URLSearchParams({ url: url })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`API Error: ${errorData.error?.message || "Unknown error"}`);
        }

        const data = await response.json();
        console.log("✅ VirusTotal Response:", data);

        return {
            detected: data.data?.attributes?.last_analysis_stats?.malicious > 0,
            analysis: data.data?.attributes?.last_analysis_stats
        };
    } catch (error) {
        console.error("Failed to check website:", error);
        throw new Error("Failed to check website: " + error.message);
    }
}

// ✅ Function to Retrieve VirusTotal API Key Securely
async function getVirusTotalApiKey() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(["virustotal_api_key"], (data) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError));
            } else if (!data.virustotal_api_key) {
                reject(new Error("API key not found in storage."));
            } else {
                resolve(data.virustotal_api_key);
            }
        });
    });
}
