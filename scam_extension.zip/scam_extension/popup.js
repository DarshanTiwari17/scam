document.getElementById("checkButton").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (tab && tab.url) {
      chrome.runtime.sendMessage({ type: "CHECK_WEBSITE", url: tab.url }, (response) => {
          if (response?.error) {
              document.getElementById("result").innerText = `❌ Error: ${response.error}`;
          } else if (response?.result?.isScam) {
              document.getElementById("result").innerText = `⚠️ Scam detected! Confidence: ${response.result.confidence * 100}%`;
          } else {
              document.getElementById("result").innerText = `✅ This site looks safe!`;
          }
      });
  } else {
      document.getElementById("result").innerText = "❌ Failed to get tab URL!";
  }
});
