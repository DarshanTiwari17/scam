chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "SCAN_RESULT") {
        if (message.result.isScam) {
            const warningBanner = document.createElement("div");
            warningBanner.textContent = `⚠️ Warning: This site may be a scam! Confidence: ${(message.result.confidence * 100).toFixed(2)}%`;
            warningBanner.style.position = "fixed";
            warningBanner.style.top = "0";
            warningBanner.style.left = "0";
            warningBanner.style.width = "100%";
            warningBanner.style.backgroundColor = "red";
            warningBanner.style.color = "white";
            warningBanner.style.textAlign = "center";
            warningBanner.style.padding = "10px";
            warningBanner.style.fontSize = "18px";
            document.body.prepend(warningBanner);
        }
    }
});
